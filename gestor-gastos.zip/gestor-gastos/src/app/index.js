import { useState } from 'react';
import { Alert, FlatList, KeyboardAvoidingView, Platform, StyleSheet, Text, TextInput, TouchableOpacity, View } from 'react-native';
// Importamos una librería nativa de Expo para usar la fuente Times New Roman

export default function App() {
  const [descripcion, setDescripcion] = useState('');
  const [monto, setMonto] = useState('');
  const [categoria, setCategoria] = useState('Alimentación'); 
  const [gastos, setGastos] = useState([]); 

  // Lista de categorías actualizada (incluye Servicios)
  const categoriasDisponibles = [
    'Alimentación', 'Transporte', 'Vivienda', 'Servicios', 
    'Deudas', 'Educación', 'Compras', 'Salud'
  ];

  const agregarGasto = () => {
    if (descripcion.trim() === '' || monto.trim() === '' || isNaN(monto)) {
      Alert.alert('Atención', 'Por favor, completá la descripción y un monto válido.');
      return;
    }

    const nuevoGasto = {
      id: Date.now().toString(), 
      descripcion: descripcion,
      monto: parseFloat(monto),
      categoria: categoria,
    };

    setGastos([...gastos, nuevoGasto]); 
    setDescripcion(''); 
    setMonto('');
  };

  const eliminarGasto = (id) => {
    setGastos(gastos.filter(gasto => gasto.id !== id));
  };

  const totalGastado = gastos.reduce((acumulador, gasto) => acumulador + gasto.monto, 0);

  return (
    <KeyboardAvoidingView 
      style={{ flex: 1, backgroundColor: '#F0F4F4' }} // Fondo gris verdoso muy suave
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <View style={styles.container}>
        
        {/* Encabezado */}
        <View style={styles.header}>
          <Text style={styles.titulo}>Gestor de Gastos</Text>
          <Text style={styles.subtitulo}>Controlá tus finanzas personales</Text>
        </View>

        {/* Tarjeta del Formulario */}
        <View style={styles.cardFormulario}>
          <TextInput
            style={styles.input}
            placeholder="Descripción (ej: Supermercado)"
            placeholderTextColor="#888"
            value={descripcion}
            onChangeText={setDescripcion}
          />
          <TextInput
            style={styles.input}
            placeholder="Monto (ej: 1500)"
            placeholderTextColor="#888"
            value={monto}
            onChangeText={setMonto}
            keyboardType="numeric"
          />
          
          {/* Categorías */}
          <Text style={styles.label}>Categoría:</Text>
          <View style={styles.categoriasContainer}>
            {categoriasDisponibles.map((cat) => (
              <TouchableOpacity
                key={cat}
                style={[styles.botonCategoria, categoria === cat && styles.categoriaSeleccionada]}
                onPress={() => setCategoria(cat)}
              >
                <Text style={[styles.textoCategoria, categoria === cat && styles.textoCategoriaSeleccionada]}>
                  {cat}
                </Text>
              </TouchableOpacity>
            ))}
          </View>

          <TouchableOpacity style={styles.botonAgregar} onPress={agregarGasto}>
            <Text style={styles.textoBotonAgregar}>+ Agregar Gasto</Text>
          </TouchableOpacity>
        </View>

        {/* Tarjeta del Total */}
        <View style={styles.cardTotal}>
          <Text style={styles.labelTotal}>TOTAL GASTADO</Text>
          <Text style={styles.montoTotal}>${totalGastado.toFixed(2)}</Text>
        </View>

        {/* Lista de Gastos */}
        <Text style={styles.tituloLista}>Últimos movimientos</Text>
        <FlatList
          style={{ flex: 1 }}
          data={gastos}
          keyExtractor={(item) => item.id}
          showsVerticalScrollIndicator={false}
          renderItem={({ item }) => (
            <View style={styles.itemGasto}>
              <View style={{ flex: 1 }}>
                <Text style={styles.textoGasto}>{item.descripcion}</Text>
                <View style={styles.filaDetalle}>
                  <Text style={styles.textoCategoriaItem}>{item.categoria}</Text>
                </View>
              </View>
              <View style={styles.derechaItem}>
                <Text style={styles.montoGasto}>-${item.monto.toFixed(2)}</Text>
                <TouchableOpacity onPress={() => eliminarGasto(item.id)} style={styles.botonEliminar}>
                  <Text style={styles.textoEliminar}>Borrar</Text>
                </TouchableOpacity>
              </View>
            </View>
          )}
          ListEmptyComponent={
            <View style={styles.contenedorVacio}>
              <Text style={styles.vacio}>No hay gastos registrados aún.</Text>
            </View>
          }
        />
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, paddingTop: 50 },
  header: { marginBottom: 20, alignItems: 'center' },
  titulo: { fontSize: 32, fontWeight: 'bold', color: '#004D40', fontFamily: 'Times New Roman' },
  subtitulo: { fontSize: 16, color: '#666', fontFamily: 'Times New Roman', fontStyle: 'italic', marginTop: 4 },
  
  // Estilos del Formulario
  cardFormulario: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3, // Sombra para Android
    marginBottom: 15,
  },
  input: {
    backgroundColor: '#F9F9F9',
    padding: 12,
    borderRadius: 8,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: '#E0E0E0',
    fontFamily: 'Times New Roman',
    fontSize: 16,
    color: '#333',
  },
  label: { fontSize: 16, fontWeight: 'bold', color: '#004D40', fontFamily: 'Times New Roman', marginBottom: 8 },
  
  // Categorías
  categoriasContainer: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 15 },
  botonCategoria: {
    paddingVertical: 6,
    paddingHorizontal: 12,
    backgroundColor: '#F0F4F4',
    borderRadius: 20,
    borderWidth: 1,
    borderColor: '#B2DFDB',
  },
  categoriaSeleccionada: { backgroundColor: '#00897B', borderColor: '#00897B' },
  textoCategoria: { color: '#004D40', fontFamily: 'Times New Roman', fontWeight: 'bold', fontSize: 13 },
  textoCategoriaSeleccionada: { color: '#FFFFFF' },

  // Botón Agregar
  botonAgregar: {
    backgroundColor: '#00897B',
    padding: 15,
    borderRadius: 8,
    alignItems: 'center',
  },
  textoBotonAgregar: { color: '#FFFFFF', fontSize: 18, fontWeight: 'bold', fontFamily: 'Times New Roman' },

  // Tarjeta de Total
  cardTotal: {
    backgroundColor: '#00897B', // Color llamativo para el total
    borderRadius: 12,
    padding: 20,
    alignItems: 'center',
    marginBottom: 20,
    shadowColor: '#00897B',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 5,
    elevation: 5,
  },
  labelTotal: { fontSize: 14, color: '#B2DFDB', fontFamily: 'Times New Roman', fontWeight: 'bold', letterSpacing: 1 },
  montoTotal: { fontSize: 36, fontWeight: 'bold', color: '#FFFFFF', fontFamily: 'Times New Roman', marginTop: 5 },

  // Lista
  tituloLista: { fontSize: 20, fontWeight: 'bold', color: '#004D40', fontFamily: 'Times New Roman', marginBottom: 10 },
  itemGasto: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    backgroundColor: '#FFFFFF',
    padding: 15,
    marginBottom: 10,
    borderRadius: 10,
    borderLeftWidth: 5,
    borderLeftColor: '#00897B', // Detalle de color a la izquierda
    elevation: 1,
  },
  textoGasto: { fontSize: 18, fontWeight: 'bold', color: '#333', fontFamily: 'Times New Roman' },
  filaDetalle: { flexDirection: 'row', marginTop: 5 },
  textoCategoriaItem: {
    fontSize: 12,
    color: '#00897B',
    backgroundColor: '#E0F2F1',
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 10,
    fontFamily: 'Times New Roman',
    fontWeight: 'bold',
    overflow: 'hidden',
  },
  derechaItem: { alignItems: 'flex-end', justifyContent: 'space-between' },
  montoGasto: { fontSize: 18, fontWeight: 'bold', color: '#D32F2F', fontFamily: 'Times New Roman' }, // Rojo suave para el gasto
  botonEliminar: { marginTop: 5, padding: 5 },
  textoEliminar: { color: '#999', fontSize: 12, fontFamily: 'Times New Roman', textDecorationLine: 'underline' },
  
  contenedorVacio: { alignItems: 'center', marginTop: 20 },
  vacio: { color: '#999', fontFamily: 'Times New Roman', fontStyle: 'italic', fontSize: 16 },
});